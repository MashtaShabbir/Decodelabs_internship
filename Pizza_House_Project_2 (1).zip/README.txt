# Pizza House — Full Stack Project 2

## What this project demonstrates
- GET API: `/api/pizzas`
- POST API: `/api/orders`
- User input and JSON responses
- Basic validation
- Frontend connected to backend with Fetch API

## Run the backend
1. Open a terminal in `backend`
2. Run:
   npm install
3. Then:
   npm start

The API runs at:
http://localhost:5000

## Open the frontend
Open `index.html` in your browser after starting the backend.

## Test GET
Open:
http://localhost:5000/api/pizzas

## Test POST in Postman
POST:
http://localhost:5000/api/orders

Body -> raw -> JSON:
{
  "customerName": "Ayesha",
  "phone": "03001234567",
  "pizzaName": "Margherita",
  "quantity": 2,
  "address": "Lahore"
}

Expected response:
201 Created with order details and total.

## Project 2 mapping
1. Create GET/POST endpoints — completed
2. Handle user input and responses — completed
3. Validate basic data — completed
