const API = "http://localhost:5000/api";

// GET API: load pizzas from backend
async function loadPizzas() {
  const cards = document.getElementById("pizzaCards");
  try {
    const response = await fetch(`${API}/pizzas`);
    const pizzas = await response.json();

    cards.innerHTML = pizzas.map(pizza => `
      <div class="card">
        <img src="${pizza.image}" alt="${pizza.name}">
        <h2>${pizza.name}</h2>
        <p>Rs. ${pizza.price}</p>
        <button onclick="selectPizza('${pizza.name.replace(/'/g, "\\'")}')">Add To Cart</button>
      </div>
    `).join("");
  } catch (error) {
    cards.innerHTML = "<p>Unable to load menu. Please start the backend server.</p>";
  }
}

function selectPizza(name) {
  document.getElementById("pizzaName").value = name;
  document.getElementById("contact").scrollIntoView({behavior:"smooth"});
}

// POST API: send customer order to backend
document.getElementById("orderForm").addEventListener("submit", async (event) => {
  event.preventDefault();

  const order = {
    customerName: document.getElementById("customerName").value.trim(),
    phone: document.getElementById("customerPhone").value.trim(),
    pizzaName: document.getElementById("pizzaName").value.trim(),
    quantity: Number(document.getElementById("quantity").value),
    address: document.getElementById("address").value.trim()
  };

  const message = document.getElementById("orderMessage");

  try {
    const response = await fetch(`${API}/orders`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(order)
    });

    const data = await response.json();
    message.textContent = data.message || data.error;

    if (response.ok) event.target.reset();
  } catch (error) {
    message.textContent = "Server is not running. Start the backend first.";
  }
});

loadPizzas();
