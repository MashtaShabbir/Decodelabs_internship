const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const pizzas = [
  {
    id: 1,
    name: "Margherita",
    price: 899,
    image: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800"
  },
  {
    id: 2,
    name: "Pepperoni",
    price: 1199,
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?w=800"
  },
  {
    id: 3,
    name: "Cheese Lovers",
    price: 1099,
    image: "https://images.unsplash.com/photo-1579751626657-72bc17010498?w=800"
  }
];

const orders = [];

// GET /api/pizzas
app.get("/api/pizzas", (req, res) => {
  res.status(200).json(pizzas);
});

// POST /api/orders
app.post("/api/orders", (req, res) => {
  const { customerName, phone, pizzaName, quantity, address } = req.body;

  // Basic validation required by Project 2
  if (!customerName || !phone || !pizzaName || !quantity || !address) {
    return res.status(400).json({
      error: "All fields are required."
    });
  }

  if (!Number.isInteger(quantity) || quantity < 1) {
    return res.status(400).json({
      error: "Quantity must be a positive whole number."
    });
  }

  const pizza = pizzas.find(
    item => item.name.toLowerCase() === String(pizzaName).toLowerCase()
  );

  if (!pizza) {
    return res.status(404).json({
      error: "Pizza not found."
    });
  }

  const order = {
    id: orders.length + 1,
    customerName,
    phone,
    pizzaName: pizza.name,
    quantity,
    address,
    total: pizza.price * quantity,
    status: "Received"
  };

  orders.push(order);

  res.status(201).json({
    message: "Order placed successfully!",
    order
  });
});

app.listen(PORT, () => {
  console.log(`Pizza API running at http://localhost:${PORT}`);
});
